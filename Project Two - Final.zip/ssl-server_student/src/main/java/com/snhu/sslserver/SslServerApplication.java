package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ChecksumController {
    @GetMapping("/hash")
    public String getHash() throws Exception {
        String data = "Hello, this is a unique data string!";
        String checksum = ChecksumUtil.generateChecksum(data);
        return "Checksum: " + checksum;
    }
}